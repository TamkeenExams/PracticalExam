using Financial_Tamkeen_Albanna.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Financial_Tamkeen_Albanna.Controllers
{
    /// <summary>
    /// Controller class with atomic database access, each crud op is dedicated in an action (endpoint). 
    /// Further improvement would be to extract all db accerss code and models into a separate class library and encapsulate it with a facade. but due to the time constraint I placed them here.
    /// Further imprrovements also include using logging, prevent over-posting (by using DTOs), and following CQRS best practices by splitting the app into two sub-apps (and DBs) one for querying data and one for commands.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        
        /// <summary>
        /// bulit-in logger that can be further used to document as much destails as possibel about the app actions and procedures to help debugging issuess or finding areas for improvement.
        /// </summary>
        private readonly ILogger<ProductController> _logger;

        /// <summary>
        /// Constructor to create a new instance of <see cref="ProductController"/>.
        /// </summary>
        /// <param name="logger"></param>
        public ProductController(ILogger<ProductController> logger)
        {
            _logger = logger;
        }


        /// <summary>
        /// End point definition for Getting all products operation. This end point (aka Action Method) displays all products currently exist in the database.
        /// </summary>
        /// <returns>Retutrns Ok status code HTTP 200</returns>
        [HttpGet(Name = "GetProducts")]
        public ActionResult<List<Product>> GetProducts()
        {
            using (var db = new ProductDbContext())
            {
                List<Product> products = db.Products.ToList();
                return Ok(products);
            };
        }

        /// <summary>
        /// End point definition for Getting a specific product operation. This end point (aka Action Method) display specified by the input parameter.
        /// </summary>
        /// <param name="id">The ID to look up the product</param>
        /// <returns>Retutrns Ok status code HTTP 200 or NOT found HTTP 404</returns>
        [HttpGet(Name ="GetProduct")]
        public ActionResult<Product> GetProduct(int id)
        {
            using (var db = new ProductDbContext())
            {
                if (db.Products.Any(p => p.ProductId == id) == false)
                    return NotFound();

                Product product = db.Products.SingleOrDefault(p => p.ProductId == id);
                return Ok(product);
            }
        }


        /// <summary>
        /// End point defintion to create a new Product in the database. 
        /// </summary>
        /// <param name="product">The <see cref="Product"/> Object to be created</param>
        /// <returns>Bad Request HTTP 400 if the creation failed. If successful then it'll return HTTP 201 with a location header speciying the location of the newly created resource.</returns>
        [HttpPost("CreateProducts")]
        public ActionResult CreateProducts(Product product)
        {
            if (product == null)
                return BadRequest();

            if (ModelState.IsValid == false)
                return BadRequest();

            using (var db = new ProductDbContext())
            {
                db.Products.Add(product);
                db.SaveChanges();
                return CreatedAtAction(nameof(CreateProducts), new { id = product.ProductId }, product);
            }
        }


        /// <summary>
        /// End point defintion to update an exisiting Product in the database. 
        /// </summary>
        /// <param name="product">The new Product object.</param>
        /// <returns>Bad Request HTTP 400 if the update failed. If successful then it'll return HTTP 201 with a location header speciying the location of the newly updated resource.</returns>
        [HttpPut("UpdateProduct")]
        public ActionResult UpdateProduct(Product product)
        {
            if (product == null)
                return BadRequest();

            if (ModelState.IsValid == false)
                return BadRequest();

            using (var db = new ProductDbContext())
            {
                var pId = product.ProductId;
                var productToUpdate = db.Products.SingleOrDefault(p=>p.ProductId == pId);
                db.Entry(productToUpdate).CurrentValues.SetValues(product);
                db.SaveChanges();
                return CreatedAtAction(nameof(CreateProducts), new { id = product.ProductId }, product);
            }
        }
    }
}