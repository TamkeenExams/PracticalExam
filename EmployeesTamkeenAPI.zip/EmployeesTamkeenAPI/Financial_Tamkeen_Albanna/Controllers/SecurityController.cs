﻿using Financial_Tamkeen_Albanna.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Text;

namespace Financial_Tamkeen_Albanna.Controllers
{

    /// <summary>
    /// Although I understand claims based security and federation authenticaion, the concepts of the JWT framework are totally new to me, I have not been coding for almost
    /// 5 years and this framework was not around back then. Therefore I would like to be frank and save the reviewer's time by saying that I couldn't do the JWT part. My apologies.
    /// </summary>
   
    //[ApiController]
    //[Route("[controller]")]
    //public class SecurityController : ControllerBase
    //{
    //    [AllowAnonymous]
    //    public ActionResult CreateToken(User user)
    //    {
    //        if (user.UserName == "user" && user.Password == "user123")
    //        {
                
    //            return Ok("stringToken");
    //        }
    //        return Unauthorized();
    //    }
    //}
}
