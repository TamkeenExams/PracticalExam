﻿using System.ComponentModel.DataAnnotations;

namespace Financial_Tamkeen_Albanna.Models
{
    /// <summary>
    /// Model Class for products.
    /// </summary>
    public class Product
    {
        /// <summary>
        /// The Product ID property.
        /// </summary>
        [Key]
        public int ProductId { get; set; }

        /// <summary>
        /// The product Name property.
        /// </summary>
        [Required]
        public string Name { get; set; }

        /// <summary>
        /// The product description property
        /// </summary>
        [Required]
        public string Description { get; set; }

        /// <summary>
        /// The product Price property
        /// </summary>
        [Required]
        public decimal Price { get; set; }

        /// <summary>
        /// The product Quantity In Stock property
        /// </summary>
        public int QuantityInStock { get; set; }

    }
}
