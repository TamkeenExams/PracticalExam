﻿namespace Financial_Tamkeen_Albanna.Models
{
    public class User
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
