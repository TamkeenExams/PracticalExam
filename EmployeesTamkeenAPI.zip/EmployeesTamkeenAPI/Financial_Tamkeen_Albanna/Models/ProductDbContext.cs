﻿using System.Data.Entity;

namespace Financial_Tamkeen_Albanna.Models
{
    /// <summary>
    /// This is the Entity Framework manager class. 
    /// </summary>
    public class ProductDbContext: DbContext
    {
        /// <summary>
        /// Creates a new instance of <see cref="ProductDbContext"/>.
        /// </summary>
        public ProductDbContext() : base("TamkeenDatabaseConnection")
        {
        }

        /// <summary>
        /// Represents list of products in the database.
        /// </summary>
        public DbSet<Product> Products { get; set; }
    }
}
